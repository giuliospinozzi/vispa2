#ifndef VERSION_GIT_H
#define VERSION_GIT_H
#define VERSION_GIT "v2.18.0-1-gd3f1ae5-dirty"
#endif /* VERSION_GIT_H */
